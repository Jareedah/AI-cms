<?php
/* From version 1.2.0 my_functions_helper.php removed from the main files and need to be created when needed.
/* Upload this file to application/helpers IF DONT EXISTS */
/* Add your own functions here */
